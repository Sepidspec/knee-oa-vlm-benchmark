Knee osteoarthritis direct multimodal grading

Mode: study
Grouping: provisional prefix; engineering benchmark

This archive contains measured outputs from this run only. The proposal dummy values are never used.
Figures: vector PDF plus notebook PNG. Tables: CSV. Captions: figures/captions.json.
Protocol: manifests, fixed prompts, model revision, environment, scoring rule, temperatures and thresholds.
Prediction rows retain failures; only complete predictions enter grade/calibration metrics.
All-case accuracy and retained coverage use all eligible cases. Paired contrasts use common-complete cases.
QWK differences are P0 minus full CNN for the primary contrast. Secondary test families use Holm.
Bootstrap units are provisional prefixes unless authoritative participant mapping was documented.
No clinical independence, external generalisation, feature explanation validity or superiority is assumed.
Training time is measured wall time on the allocated GPU, not device-utilisation GPU-hours.
Timing includes synchronization instrumentation; component means are instrumented estimates.
No source images, pretrained base weights, or adapter weights are redistributed in this analysis archive.
CNN checkpoints and LoRA adapter files remain in the Kaggle working directory. Preserve them privately
as Kaggle output for resume; redistribution requires compliance with the respective source terms.
For cross-session resume, mount the prior output directory and set resume_from to its pilot/study directory.
